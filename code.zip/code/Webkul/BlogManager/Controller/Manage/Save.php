<?php
namespace Webkul\BlogManager\Controller\Manage;

use Magento\Customer\Controller\AbstractAccount;
use Magento\Framework\App\Action\Context;

class Save extends AbstractAccount
{
    /**
     * @var \Webkul\BlogManager\Model\BlogFactory
     */
    protected $blogFactory;

    /**
     * Dependency Initilization
     *
     * @param Context $context
     * @param \Webkul\BlogManager\Model\BlogFactory $blogFactory
     */
    public function __construct(
        Context $context,
        \Webkul\BlogManager\Model\BlogFactory $blogFactory
    ) {
        $this->blogFactory = $blogFactory;
        parent::__construct($context);
    }

    /**
     * Provides content
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $data = $this->getRequest()->getParams();
        
//    print_r($data); die;
        
        $model = $this->blogFactory->create();
        $model->setCustomername($data['customername']);
        $model->setProductname($data['productname']);
        $model->setProductprice($data['productprice']);
        $model->setProductsku($data['productsku']);
        $model->setAddress($data['address']);
         $model->setEmail($data['email']);
          $model->setPhone($data['phone']);
          $model->setEnquerydata($data['enquerydata']); 
        $model->save();
        echo 'Saved';
    }
}
