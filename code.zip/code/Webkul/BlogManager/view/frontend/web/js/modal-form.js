define(
    [
        'jquery',
        'Magento_Ui/js/modal/modal'
    ],
    function($) {
        "use strict";
        //creating jquery widget
        $.widget('Vendor.modalForm', {
            options: {
                modalForm: '#modal-form',
                modalButton: '.open-modal-form'
            },
            _create: function() {
                this.options.modalOption = this._getModalOptions();
                this._bind();
            },
            _getModalOptions: function() {
                /**
                 * Modal options#modal-form
                 */
                var options = {
                    type: 'popup',
                    responsive: true,
                    buttons: [{
                        text: $.mage.__('Sumbit'),
                        class: '',
                        click: function () {
                             this.closeModal();

                            // setTimeout(() => {
                                var customername = $("#name").val(); 
                                var productname = $("#number").val();
                                var productprice = $("#price").val();
                                var productsku = $("#sku").val();
                                var address = $("#quantity").val(); 
                                var email = $("#content").val();
                                var phone = $("#Status").val();
                                var enquerydata = $("#enquerydata").val();
                                 $.ajax({
                                     url: "http://magento2.local/blog/manage/save",
                                     type: "POST",
                                     data: {
                                        customername: customername,
                                        productname: productname,
                                        productprice: productprice,
                                        productsku: productsku,
                                        address: address,
                                        email: email,
                                        phone: phone,
                                        enquerydata: enquerydata 
                                     },
                                     success: function(response){
                                        // this.closeModal();
                                     console.log(response);
                                 }
                                 });
                            // },1500)

                           
                            
                        }
                    }]
                };

                return options;
            },
            _bind: function(){
                var modalOption = this.options.modalOption;
                var modalForm = this.options.modalForm;

                $(document).on('click', this.options.modalButton,  function(){
                    //Initialize modal
                    $(modalForm).modal(modalOption);
                    //open modal
                    $(modalForm).trigger('openModal');
                });
            }
        });

        return $.Vendor.modalForm;
    }
);
