<?php
namespace Webkul\BlogManager\Block;

class BlogList extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Webkul\BlogManager\Model\ResourceModel\Blog\CollectionFactory
     */
    protected $blogCollection;
    protected $registry;
    /**
     * Dependency Initilization
     *
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Webkul\BlogManager\Model\ResourceModel\Blog\CollectionFactory $blogCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Webkul\BlogManager\Model\ResourceModel\Blog\CollectionFactory $blogCollection, 
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->blogCollection = $blogCollection;
        $this->registry = $registry;
        parent::__construct($context, $data);
        
    }

    /**
     * Get Blog List
     *
     * @return \Webkul\BlogManager\Model\ResourceModel\Blog\Collection
     */
    public function getBlogs()
    {
         $collection = $this->blogCollection->create();
         return $collection;
       
    }
    public function getCurrentProduct()
    {
        return $this->registry->registry('current_product');
    }

    public function getCurrentProduct1()
    {
       //return $productid = $this->getCurrentProduct()->getResources()->getAttribute("sample_yes_no");
       $product = $this->getProduct();
$ressource = $product->getResource();
$store = $this->_storeManager->getStore();

$ressource->getAttributeRawValue($product->getId(),'sample_yes_no',$store->getId());

    }
}
